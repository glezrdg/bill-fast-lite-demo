export interface Cliente {
  nombreORazonSocial: string;
  tipoDeDocumento: string;
  numeroDeDocumento: number;
  correoClientes: string;
  telefono: number;
  celular: number;
  direccion: string;
  comentarios: string;
}