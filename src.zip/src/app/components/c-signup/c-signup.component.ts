import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-signup',
  templateUrl: './c-signup.component.html',
  styleUrls: ['./c-signup.component.scss']
})
export class CSignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
