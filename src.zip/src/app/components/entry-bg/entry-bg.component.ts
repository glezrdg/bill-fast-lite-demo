import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entry-bg',
  templateUrl: './entry-bg.component.html',
  styleUrls: ['./entry-bg.component.scss']
})
export class EntryBgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
