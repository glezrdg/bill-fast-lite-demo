import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-login',
  templateUrl: './c-login.component.html',
  styleUrls: ['./c-login.component.scss']
})
export class CLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  miloco() {
    console.log('mi loco');
    
  }

}
