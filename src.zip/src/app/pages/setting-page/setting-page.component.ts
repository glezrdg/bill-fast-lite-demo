import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-page',
  templateUrl: './setting-page.component.html',
  styleUrls: ['./setting-page.component.scss']
})
export class SettingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
