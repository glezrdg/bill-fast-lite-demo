import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-more-opt-page',
  templateUrl: './more-opt-page.component.html',
  styleUrls: ['./more-opt-page.component.scss']
})
export class MoreOptPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
