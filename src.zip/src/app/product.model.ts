export interface Product {
    name: string;
    price: number;
    img: string; 
    category?: string;
}